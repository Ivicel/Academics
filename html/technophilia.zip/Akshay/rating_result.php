<?php

class RatingResult
{
	public $returnCode=500;
	public $returnMessage='';
}
?>