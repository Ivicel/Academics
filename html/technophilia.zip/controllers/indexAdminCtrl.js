var app = angular.module('myApp');

app.controller('indexAdminCtrl', ['$scope', function($scope) {
	console.log("Fron IndexCtrl");													
}]);
